using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hangfire.HttpJob.Agent;

namespace test.job
{
  public class ScheduledJob:JobAgent
  {
    protected override async Task OnStart(JobContext jobContext)
    {
      System.Diagnostics.Debug.WriteLine("Scheduled Job.");
      System.Diagnostics.Debug.WriteLine(System.DateTime.Now.ToString("F"));
    }
    protected override void OnException(Exception ex)
    {
      throw new NotImplementedException();
    }
    protected override void OnStop(JobContext jobContext)
    {
      throw new NotImplementedException();
    }
  }
}
